# Yeelight App

Installation Instructions:

1. Download the `.zip` file for the latest release
2. Extract the `.zip` file to a new folder
3. Run the 